Wingiton stock app

Updated invoice import parser.

New in this version:
- Added optional AI PDF invoice reader.
- AI extraction reads only the invoice item description/name and quantity supplied/delivered.
- AI results are placed into the existing invoice preview and are not added to stock until the user clicks "Add Invoice Items To Stock".
- OpenAI API key and model are saved only in this browser/device localStorage.

Security note:
For shared/public use, do not put a permanent API key in the app. Use a restricted key or a backend/proxy so the key is not exposed in browser code.
